import { Handler } from '@netlify/functions';
import nodemailer from 'nodemailer';

const transporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST,
  port: parseInt(process.env.SMTP_PORT || '587'),
  secure: false,
  auth: {
    user: process.env.SMTP_USER,
    pass: process.env.SMTP_PASS,
  },
});

export const handler: Handler = async (event) => {
  if (event.httpMethod !== 'POST') {
    return {
      statusCode: 405,
      body: 'Method Not Allowed',
    };
  }

  try {
    const { email, resource } = JSON.parse(event.body || '{}');

    if (!email || !resource) {
      return {
        statusCode: 400,
        body: JSON.stringify({ message: 'Email and resource are required' }),
      };
    }

    const resourceMap = {
      'Healthcare Cost Guide': '/resources/healthcare-cost-guide.pdf',
      'ER Utilization Analysis Template': '/resources/er-analysis-template.xlsx',
    };

    const resourcePath = resourceMap[resource];
    if (!resourcePath) {
      return {
        statusCode: 400,
        body: JSON.stringify({ message: 'Invalid resource requested' }),
      };
    }

    // Send email with resource
    await transporter.sendMail({
      from: process.env.SMTP_FROM,
      to: email,
      subject: `Your Requested Resource: ${resource}`,
      html: `
        <h1>Thank you for your interest in ${resource}</h1>
        <p>Please find your requested resource attached.</p>
        <p>If you have any questions, please don't hesitate to contact us.</p>
        <br>
        <p>Best regards,</p>
        <p>BenefitsPlus Team</p>
      `,
      attachments: [
        {
          filename: resourcePath.split('/').pop(),
          path: `${process.env.URL}${resourcePath}`,
        },
      ],
    });

    return {
      statusCode: 200,
      body: JSON.stringify({ message: 'Resource sent successfully' }),
    };
  } catch (error) {
    console.error('Error sending resource:', error);
    return {
      statusCode: 500,
      body: JSON.stringify({ message: 'Error sending resource' }),
    };
  }
};